export class GetAttributeArgs {
  id?: number;
  slug?: string;
  language?: string;
}
