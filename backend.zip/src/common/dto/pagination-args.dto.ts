export class PaginationArgs {
  // FIX ME
  first?: number = 15;
  limit?: number = 15;
  page?: number = 1;
}
