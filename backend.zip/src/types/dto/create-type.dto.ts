export class CreateTypeDto {}
