export class GetReportDto {
  modal_id?: string;
}
