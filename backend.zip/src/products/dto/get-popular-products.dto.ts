export class GetPopularProductsDto {
  type_slug?: string;
  limit: number;
  shop_id?: number;
}
