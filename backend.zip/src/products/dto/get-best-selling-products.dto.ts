export class GetBestSellingProductsDto {
  type_slug?: string;
  limit: number;
  shop_id?: number;
}
