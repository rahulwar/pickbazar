export class GetTopManufacturersDto {
  limit: number;
}
