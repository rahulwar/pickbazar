import { CoreEntity } from 'src/common/entities/core.entity';

export class MyReports extends CoreEntity {
  message: string;
}
