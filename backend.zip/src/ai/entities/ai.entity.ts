export class Ai {
  status: 'success' | 'failed';
  result: string;
}
