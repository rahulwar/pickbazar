export class OrderPaymentDto {
  tracking_number: number;
}
