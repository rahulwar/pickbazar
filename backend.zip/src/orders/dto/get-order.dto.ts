export class GetOrderArgs {
  id?: number;
  tracking_number?: string;
}
